************************************************************

	Instituto Tecnológico de Costa Rica
	Ingeniería en Computadores

	Programador: Esteban Agüero Pérez (estape11)

	Última Modificación: 10/04/2019

	Arquitectura de Computadores
	Prof. Jeferson González Gómez

************************************************************
> Para compilar
		make all

> Para ejecutar
	* MaxColumn:
		$ ./bin/MaxColumn <vecA> <vecB>
		- Donde vecA y vecB son vectores de 8 elementos cada uno.
		- Ejemplo: ./bin/MaxColumn 1,2,3,4,5,6,7,8 8,7,6,5,4,3,2,1
	* hello_simd:
		$ ./bin/hello_simd
	* MultiMatrix:
		$ ./bin/MultiMatrix
> Dentro de src/mainMultiMatrix.c
	Se define la función para el producto de matrices.