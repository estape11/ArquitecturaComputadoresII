************************************************************

	Instituto Tecnológico de Costa Rica
	Ingeniería en Computadores

	Programador: Esteban Agüero Pérez (estape11)

	Última Modificación: 15/02/2019

	Arquitectura de Computadores II
	Prof. Jeferson González Gómez

************************************************************

> Comando para la compilacion:
	g++ main.cpp -o HilosEstape -pthread -std=gnu++11
> Comando para la ejecucion:
	./HilosEstape
